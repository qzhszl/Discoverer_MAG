# -*- coding: utf-8 -*-
import multiprocessing
from time import time

import pymongo
import pandas as pd
from utils.connect_to_table import connectTable

__author__ = "ZHIHAO QIU"
import math
from scipy import stats

'''
P0=  𝑃^0 (𝑑_𝑖│𝑘_𝑖,𝑝_𝐷,𝐻_0 )=∑1_(𝑛=𝑑𝑖)^(𝑘_𝑖)▒(𝑘_𝑖¦𝑛)  𝑝_𝐷^𝑛 〖(1−𝑝_𝐷 )〗^(𝑘_𝑖−𝑛)  :{1:0.5,2:0.7}
s= - ln P0
in 2021.8.13, we used this for mag_researchers0810
in 2021.9.1 we used this function in researchers0810_trainingset
'''


def initialize_surprisal():
    col_author = connectTable("qiuzh", "researchers0810_trainingset")

    cursor = col_author.find(no_cursor_timeout=True)
    # researcher_number = cursor.count()
    # print(researcher_number)
    count = 0
    operation = []
    for author in cursor:
        count += 1
        operation.append(pymongo.UpdateOne({"_id": author["_id"]}, {"$set": {"sur": -6, "bsur": -6}}))

        if count % 10000 == 0:
            print("已处理:", count / 10000, flush=True)
            col_author.bulk_write(operation, ordered=False)
            print("已写入:", count / 10000, flush=True)
            operation = []
    if operation:
        col_author.bulk_write(operation, ordered=False)
    print("finished")
    cursor.close()
    print(count)
    print(col_author.find({"dn":-1},no_cursor_timeout=True).count())


def author_surprisal(begin, end, msg, P_d):
    '''
    this function is appropriate for mag_authors0510
    How many times do an author discover others in his career life.
    :return:
    '''
    col_author = connectTable("qiuzh", "researchers0810_trainingset")
    count = 0
    operation = []

    # cursor_count = col_author.find({"iftop": 1}, no_cursor_timeout=True).count()
    # print(cursor_count)
    cursor = col_author.find(no_cursor_timeout=True)[begin:end]
    for author in cursor:
        count += 1
        author_id = author["_id"]
        d_i = author["dn"]
        k_i = author["new_con"]
        P = stats.binom.sf(d_i - 1, k_i, P_d)
        if P == 0:
            surprisal = -1
        else:
            surprisal = -math.log(P)
        operation.append(pymongo.UpdateOne({"_id": author_id},
                                                {"$set": {"sur": surprisal}}))

        if count % 10000 == 0:
            print(msg, "已处理:", count / 10000, flush=True)
            col_author.bulk_write(operation, ordered=False)
            print(msg, "已写入:", count / 10000, flush=True)
            operation = []
            print(time(), flush=True)
    if operation:
        col_author.bulk_write(operation, ordered=False)
        print(msg,"最终又完成",len(operation))
    cursor.close()


def researcher_surprisal_patch(P_d):
    '''
    We find that some researchers have too many coauthor relationships and maybe discovery times, thus leads a extremely
    small P (goes to 0) and extremely high(goes to plus infinity). We want to pick up this data and see what happens.
    :param P_d:
    :return:
    '''
    col_author = connectTable("qiuzh", "mag_authors0510")
    count = 0
    cursor = col_author.find({"sur": -1}, no_cursor_timeout=True)
    print(cursor.count())
    datadf = pd.DataFrame(columns=["di", "ki", "P"])
    for author in cursor:
        count += 1
        d_i = author["dn"]
        k_i = author["con"]
        P = stats.binom.sf(d_i - 1, k_i, P_d)
        datadf = datadf.append({'di': d_i, 'ki': k_i, 'P': P}, ignore_index=True)
    cursor.close()

    datadf.to_csv('topdiscoverer.csv', sep=',', header=True, index=True)
    return 0


if __name__ == '__main__':
    # # author_discover_number(1,5,1)
    # '''
    # 1004660932 4301786343 0.23354505591260138
    # '''
    D = 732123
    L = 68284344

    P_d = D / L
    print(D, L, P_d)
    start = time()

    p1 = multiprocessing.Process(target=author_surprisal,
                                 args=(216585 * 0, 216585 * 0 + 216585, 1, P_d))
    p2 = multiprocessing.Process(target=author_surprisal,
                                 args=(216585 * 1, 216585 * 1 + 216585, 2, P_d))
    p3 = multiprocessing.Process(target=author_surprisal,
                                 args=(216585 * 2, 216585 * 2 + 216585, 3, P_d))
    p4 = multiprocessing.Process(target=author_surprisal,
                                 args=(216585 * 3, 216585 * 3 + 216585, 4, P_d))
    p5 = multiprocessing.Process(target=author_surprisal,
                                 args=(216585 * 4, 216585 * 4 + 216585, 5, P_d))

    p1.start()
    p2.start()
    p3.start()
    p4.start()
    p5.start()

    p1.join()
    p2.join()
    p3.join()
    p4.join()
    p5.join()

    end = time()
    print("run time: %s" % ((end - start)/60))

    # D = 1004660932
    # L = 4301786343
    #
    # P_d = D / L
    # researcher_surprisal_patch(P_d)