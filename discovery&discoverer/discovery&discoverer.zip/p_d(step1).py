# -*- coding: utf-8 -*-
import math

from utils.connect_to_table import connectTable

__author__ = "ZHIHAO QIU"
import numpy as np
import pandas as pd
'''
In data_analysis/data_analysis.py, we have calculated if top scientists, coauthor, citation, and discovering or discovered
for each authors (see details in mag_authors0510)
We begin to calculate the P_d and find our discoverers in the dataset.
P_d  =  D/ L, where D is the sum of discovery times and L is the sum of the coauthor times
PS we calculate D/d_i in the data_analysis/data_analysis.py
in 2021.8.13, we used this for mag_researchers0810
in 2021.9.1 we used this function in researchers0810_trainingset
'''
# coauthor_degree_dict = {}
# to avoid memory error,step1:


def calculate_D():
    D = 0
    col_author = connectTable("qiuzh", "researchers0810_trainingset")
    cursor = col_author.find(no_cursor_timeout=True)
    for author in cursor:
        D = D+ author["dn"]
    cursor.close()
    print(D)
    return D


def calculate_L():
    D = 0
    col_author = connectTable("qiuzh", "researchers0810_trainingset")
    cursor = col_author.find(no_cursor_timeout=True)
    for author in cursor:
        D = D+ author["new_con"]
    cursor.close()
    print(D)
    return D

if __name__ == '__main__':
    # col_author = connectTable("qiuzh", "mag_authors0510").find({"dn":{"$exists":False}})
    # print(col_author.count())
    D = calculate_D()
    L = calculate_L()
    P_d = D/L
    print(D, L, P_d)
