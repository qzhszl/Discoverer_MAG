# -*- coding: utf-8 -*-
import math
import multiprocessing
from time import time

import pymongo

from utils.connect_to_table import connectTable

__author__ = "ZHIHAO QIU"
import numpy as np
import pandas as pd
'''

All the co-authorship are equally likely to become a positive discovery.
p_D=D/L, where D is the total number of positive discoveries and L is the total number of collaboration, k_i is the author degree, i.e. the number of collaboration
mag_authors0510:max bsur: 2.4618724582079023
mag_researchers0810: max busr: 1.902873871114323

'''


def find_discoverer(maxbsur,begin,end,msg):
    col_author = connectTable("qiuzh", "mag_researchers0810")
    cursor = col_author.find(no_cursor_timeout=True)[begin:end]
    count =0
    operation=[]
    for author in cursor:
        count += 1
        sur = author["sur"]
        author_id = author["_id"]
        if sur >=0 and sur < maxbsur:
            operation.append(pymongo.UpdateOne({"_id": author_id},
                                               {"$set": {"ifdis": 0}}))
        else:
            operation.append(pymongo.UpdateOne({"_id": author_id},
                                               {"$set": {"ifdis": 1}}))

        if count % 10000 == 0:
            print(msg,"已处理:", count / 10000, flush=True)
            col_author.bulk_write(operation, ordered=False)
            print(msg,"已写入:", count / 10000, flush=True)
            operation = []
            print(time(), flush=True)
    if operation:
        col_author.bulk_write(operation, ordered=False)
        print(msg,"又写入并完成",len(operation))
    cursor.close()


if __name__ == '__main__':
    # boot_strap(0.2,1,5,1)
    maxbsur = 1.902873871114323
    start = time()

    p1 = multiprocessing.Process(target=find_discoverer,
                                 args=(maxbsur, 216585 * 0, 216585 * 0 + 216585, 1))
    p2 = multiprocessing.Process(target=find_discoverer,
                                 args=(maxbsur, 216585 * 1, 216585 * 1 + 216585, 2))
    p3 = multiprocessing.Process(target=find_discoverer,
                                 args=(maxbsur, 216585 * 2, 216585 * 2 + 216585, 3))
    p4 = multiprocessing.Process(target=find_discoverer,
                                 args=(maxbsur, 216585 * 3, 216585 * 3 + 216585, 4))
    p5 = multiprocessing.Process(target=find_discoverer,
                                 args=(maxbsur, 216585 * 4, 216585 * 4 + 216585, 5))

    p1.start()
    p2.start()
    p3.start()
    p4.start()
    p5.start()

    p1.join()
    p2.join()
    p3.join()
    p4.join()
    p5.join()

    end = time()
    print("run time: %s" % ((end - start)/60))


