# -*- coding: utf-8 -*-
import multiprocessing
from collections import Counter
from time import time

import pandas as pd
import pymongo
from scipy import stats

from utils.connect_to_table import connectTable

__author__="ZHIHAO QIU"
import numpy as np
import math
"""
use bootstrap to simulate the probability of discoverers:
bootstrap_p0: p0(dict)
di :(dict) number of discoveries of author i
surprisal: surprisal(dict)

"""


def boot_strap(P_d,begin,end,msg):
    col_author = connectTable("qiuzh", "mag_researchers0810")
    cursor = col_author.find(no_cursor_timeout=True)[begin:end]
    count =0
    operation=[]
    for author in cursor:
        count += 1
        coauthor_times = author["new_con"]
        author_id = author["_id"]
        d_i_list = np.random.binomial(coauthor_times, P_d, 20)
        surprisal_list =[]
        for di in d_i_list:
            P0 = stats.binom.sf(di - 1, coauthor_times, P_d)
            surprisal_list.append(-math.log(P0))
        S = np.mean(surprisal_list)
        operation.append(pymongo.UpdateOne({"_id": author_id},
                                           {"$set": {"bsur": S}}))

        if count % 10000 == 0:
            print(msg,"已处理:", count / 10000, flush=True)
            col_author.bulk_write(operation, ordered=False)
            print(msg,"已写入:", count / 10000, flush=True)
            operation = []
            print(time(), flush=True)
    if operation:
        col_author.bulk_write(operation, ordered=False)
        print(msg,"又写入并完成",len(operation))
    cursor.close()


if __name__ == '__main__':
    # boot_strap(0.2,1,5,1)
    D = 732123
    L = 68284344

    p_d = D / L
    start = time()

    p1 = multiprocessing.Process(target=boot_strap,
                                 args=(p_d, 216585 * 0, 216585 * 0 + 216585, 1))
    p2 = multiprocessing.Process(target=boot_strap,
                                 args=(p_d, 216585 * 1, 216585 * 1 + 216585, 2))
    p3 = multiprocessing.Process(target=boot_strap,
                                 args=(p_d, 216585 * 2, 216585 * 2 + 216585, 3))
    p4 = multiprocessing.Process(target=boot_strap,
                                 args=(p_d, 216585 * 3, 216585 * 3 + 216585, 4))
    p5 = multiprocessing.Process(target=boot_strap,
                                 args=(p_d, 216585 * 4, 216585 * 4 + 216585, 5))

    p1.start()
    p2.start()
    p3.start()
    p4.start()
    p5.start()

    p1.join()
    p2.join()
    p3.join()
    p4.join()
    p5.join()

    end = time()
    print("run time: %s" % ((end - start)/60))


